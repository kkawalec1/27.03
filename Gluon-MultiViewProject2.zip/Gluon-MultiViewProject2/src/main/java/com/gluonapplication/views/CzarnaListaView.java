package com.gluonapplication.views;


import com.gluonhq.charm.glisten.animation.BounceInRightTransition;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.control.FloatingActionButton;
import com.gluonhq.charm.glisten.control.Icon;
import com.gluonhq.charm.glisten.mvc.View;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class CzarnaListaView extends View {
    public CzarnaListaView () {
        getStylesheets().add(CzarnaListaView.class.getResource("czarnalista.css").toExternalForm());

        Label label = new Label("Czarna lista!");

        VBox controls = new VBox(label);
        controls.setAlignment(Pos.CENTER);

        setCenter(controls);

        setShowTransitionFactory(BounceInRightTransition::new);

        FloatingActionButton floatingActionButton = new FloatingActionButton(MaterialDesignIcon.INFO.text,
                e -> System.out.println("Info"));
        floatingActionButton.showOn(this);
//--------------------------------------------------------------------------------------------------
        Label label2 = new Label("Hello JavaFX World!");

        Button button = new Button("Change the World!");
        button.setGraphic(new Icon(MaterialDesignIcon.LANGUAGE));
        button.setOnAction(e -> label2.setText("Hello JavaFX Universe!"));

        VBox controls2 = new VBox(15.0, label2, button);
        controls2.setAlignment(Pos.BASELINE_LEFT);

        setCenter(controls2);



    }

    @Override
    protected void updateAppBar(AppBar appBar) {
        appBar.setNavIcon(MaterialDesignIcon.MENU.button(e -> getAppManager().getDrawer().open()));
        appBar.setTitleText("Czarna lista");
        appBar.getActionItems().add(MaterialDesignIcon.FAVORITE.button(e -> System.out.println("Favorite")));
    }
}
















